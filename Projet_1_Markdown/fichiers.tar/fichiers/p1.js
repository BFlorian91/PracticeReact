// Créer ton premier component

// REACT
import React from 'react';
import { render } from 'react-dom';

class App extends React.Component {
	render() {
		return (
			<h1>Coucou</h1>
		)
	}
}

render(
  <App />,
  document.getElementById('root')
);