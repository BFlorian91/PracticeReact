import Rebase from 're-base';

const base = Rebase.createClass({
	apiKey: "AIzaSyBZHdi0IAJeQvRUxfWvLRFwSJ9PIvfH0Zc",
	authDomain: "chatboxs-77c28.firebaseapp.com",
	databaseURL: "https://chatboxs-77c28.firebaseio.com"
});

export default base;