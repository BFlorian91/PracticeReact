import React from 'react';

const NotFound = () => {
	return (
		<h2 className="notFound">Y'a rien ici!</h2>
	)
}

export default NotFound;