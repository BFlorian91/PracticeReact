import React from 'react';
import { render } from 'react-dom';
import Connexion from './components/Connexion'
//CSS
import './index.css';

render(
  <Connexion />,
  document.getElementById('root')
);