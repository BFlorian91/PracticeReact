import React from 'react';

class Message extends React.Component {
	render() {
		return (
			<p className="user-message">
				Pseudo: Mon super message.
			</p>
		)
	}
}

export default Message;